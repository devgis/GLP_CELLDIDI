﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nest;
using CsvHelper;
using System.IO;
using System.Text;
using DidiWebApp.Models;
using System.Threading;

namespace DidiWebApp.Controllers
{
    public class DataLoader
    {
        public DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime); return dtStart.Add(toNow);
        }
        public  void Load(ElasticClient es)
        {
            FileStream fs = new FileStream(@"E:\code\DidiWebApp\DidiWebApp\DidiWebApp\App_Data\order_20161101", FileMode.Open, FileAccess.Read);
            TextReader textReader = new StreamReader(fs, Encoding.UTF8);
            CsvReader csv = new CsvReader(textReader);
            List<GeoCar> cars = new List<GeoCar>();
            while (csv.Read())
            {
                GeoCar car = new GeoCar
                {
                    carid = csv.GetField<string>(0),
                    start_time = GetTime(csv.GetField<string>(1)),
                    end_time = GetTime(csv.GetField<string>(2)),
                    start_point = new Geo
                    {
                        lat = csv.GetField<string>(4),
                        lon = csv.GetField<string>(3)
                    },
                    end_point = new Geo
                    {
                        lat = csv.GetField<string>(6),
                        lon = csv.GetField<string>(5)
                    }
                };

                cars.Add(car);
            }

                //var indexResponse = es.Index(car, f => f.Index("didi").Type("doc"));

                var observableBulk = es.BulkAll(cars, f => f
                    .MaxDegreeOfParallelism(8)
                    .BackOffTime(TimeSpan.FromSeconds(10))
                    .BackOffRetries(2)
                    .Size(1000)
                    .RefreshOnCompleted()
                    .Index("didi")
                    .Type("doc")
                    );

                var seenPages = 0;
                var bulkObserver = observableBulk.Wait(TimeSpan.FromMinutes(5), b => Interlocked.Increment(ref seenPages));
                //var count = es.Count<>(f => f.Index("didi"));
                //Console.WriteLine("didi rows:" + count);
    
            csv.Dispose();

        }
    }
}