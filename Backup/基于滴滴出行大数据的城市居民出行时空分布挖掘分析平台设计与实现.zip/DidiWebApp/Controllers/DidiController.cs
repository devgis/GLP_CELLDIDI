﻿using DidiWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using Nest;


namespace DidiWebApp.Controllers
{
    public class DidiController : ApiController
    {

        ElasticClient es = new ElasticClient(new Uri("http://127.0.0.1:9200"));

        [HttpGet]
        //按区域统计
        public IEnumerable<TimeResult> StatZoneByHours(string point = "start_point", string time = "start_time", double minlat = 30.652828, double maxlat = 30.727818, double minlon = 104.042102, double maxlon = 104.129591)
        {
            List<TimeResult> result = new List<TimeResult>();

            var searchResponse = es.Search<GeoCar>(s => s
                  .Index("didi")
                  .Type("doc")
                  .Size(0)
                  .Query(q => q
                    .Bool(b => b
                      .Must(m => m
                          .MatchAll()
                       )
                      .Filter(f => f
                          .GeoBoundingBox(box => box
                              .Field(new Field(point))
                              .BoundingBox(maxlat, minlon, minlat, maxlon)
                              )
                      )
                     )
                    )

                .Aggregations(a => a
                 .DateHistogram("didi_hours", g => g
                 .Field(new Field(time))
                 .Interval(DateInterval.Hour)
                 .TimeZone("+08:00")
                 )
                 )
              );

            var aggResult = searchResponse.Aggs.DateHistogram("didi_hours");
            var buckets = aggResult.Buckets;
            foreach (Nest.DateHistogramBucket bucket in buckets)
            {
                TimeResult t = new TimeResult{
                    count = (long)bucket.DocCount,
                    //"2016-11-01T00:00:00.000+08:00"
                    time = bucket.KeyAsString.Substring(11,5)
                };
                 result.Add(t);
               
            }

            return result;
        }

        [HttpGet]
        //格网统计
        public IEnumerable<GirdResult> StatGrid(string point = "start_point", string time = "start_time", double minlat = 30.652828, double maxlat = 30.727818, double minlon = 104.042102, double maxlon = 104.129591, int level = 5, int hour = -1)
        {
            List<GirdResult> result = new List<GirdResult>();

            DateTime dt1 ;
            DateTime dt2 ;

            if (hour == -1)
            {
                 dt1 = new DateTime(2016, 11, 1, 0, 0, 0);
                 dt2 = new DateTime(2016, 11, 2, 0, 0, 0);
            }
            else
            {
                dt1 = new DateTime(2016, 11, 1, hour, 0, 0);
                dt2 = dt1.AddHours(1);
            }

            var searchResponse = es.Search<GeoCar>(s => s
                  .Index("didi")
                  .Type("doc")
                  .Size(0)
                  .Query(q => q
                    .Bool(b => b
                      .Must(m => m
                           //.MatchAll()
                          .DateRange(r => r
                              .Field(new Field(time))
                              .GreaterThanOrEquals(DateMath.Anchored(dt1))
                              .LessThan(DateMath.Anchored(dt2))
                              .TimeZone("+08:00")
                          )
                       ) 
                      .Filter(f => f
                          .GeoBoundingBox( box =>box
                              .Field(new Field(point))
                              .BoundingBox(maxlat, minlon, minlat, maxlon)
                              )
                      )
                     )
                    )

                .Aggregations(a => a
                 .GeoHash("didi_geohash_grid", g => g
                 .Field(new Field(point))
                 .GeoHashPrecision((GeoHashPrecision)level)
                 //.Size(1000)
                 //.ShardSize(100)
                 )
                 )
              );

            var aggResult = searchResponse.Aggs.GeoHash("didi_geohash_grid");
            var buckets = aggResult.Buckets;
            foreach (Nest.KeyedBucket<string> bucket in buckets)
            {
                 GirdResult g = new GirdResult{
                    count = (long)bucket.DocCount,
                    cell = bucket.Key
                };
                 result.Add(g);
            }


            return result;
        }

        [HttpGet]
        //装载数据
        public void LoadData()
        {
            DataLoader dd = new DataLoader();
            dd.Load(es);

        }
    }
}
