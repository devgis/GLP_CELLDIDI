﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DidiWebApp.Models
{
    public class GeoCar
    {
        public string carid { get; set; }
        public DateTime start_time { get; set; }
        public DateTime end_time { get; set; }
        public Geo start_point { get; set; }
        public Geo end_point { get; set; }
    }
}