﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DidiWebApp.Models
{
    public class GirdResult
    {
        //public double minlat { get; set; }
        //public double maxlat { get; set; }
        //public double minlon { get; set; }
        //public double maxlon { get; set; }
        public long count { get; set; }
        public string cell { get; set; }
    }
}